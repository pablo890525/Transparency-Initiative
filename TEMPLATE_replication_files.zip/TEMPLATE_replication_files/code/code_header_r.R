######## INFO ######## 

# PROJECT 
  # Paper: 
  # Authors: 

# DO FILE
  # Created: 
  # Updated: 
  # Inputs: 
  # Outputs:

######## SETUP ######## 

  rm(list = ls()) # clear workspace
  setwd("~/Documents/replication files")

######## PACKAGES ########

# This bit of code checks a user's system and only installs packages they don't have  
  need <- c("dplyr", "foreign", "ggplot2", "stargazer") # packages needed
  have <- need %in% rownames(installed.packages()) # packages you have
  if(any(!have)) install.packages(need[!have]) # install missing packages
  invisible(lapply(need, library, character.only=T)) # load needed packages
  

